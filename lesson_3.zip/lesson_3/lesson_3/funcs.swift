//
//  funcs.swift
//  Lesson_3
//
//  Created by k.kochemasov on 05/03/2019.
//  Copyright © 2019 k.kochemasov. All rights reserved.
//

import Foundation
